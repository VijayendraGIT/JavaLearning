package mavenTest;

import org.testng.annotations.Test;

public class BasicTests {

	@Test
	public void mavenCheck(){
		System.out.println("Maven checking");
	}
	
	@Test
	public void mavenCheck2(){
		System.out.println("Maven checking");
	}
	
}
