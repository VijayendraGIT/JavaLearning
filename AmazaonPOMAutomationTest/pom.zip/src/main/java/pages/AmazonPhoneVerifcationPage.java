package pages;

public class AmazonPhoneVerifcationPage {

}
