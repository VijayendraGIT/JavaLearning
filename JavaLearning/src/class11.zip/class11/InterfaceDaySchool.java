package class11;

public interface InterfaceDaySchool {
	
	void DayClass();

}
