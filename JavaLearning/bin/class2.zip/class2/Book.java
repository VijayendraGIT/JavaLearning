package class2;

public class Book {
	//Class properties
	int chapters;
	int pages;

	public static void main(String[] args) {
// Object => new Book(); 
// Object refrence => englishBook, hindiBook
		
		Book englishBook = new Book();
		englishBook.chapters = 10;
		englishBook.pages = 200;
		
		Book hindiBook	= new Book();
		hindiBook.chapters = 12;
		hindiBook.pages =250;
		
		System.out.println("English Book Cotains :chapters ="+englishBook.chapters);
		

	}

}
