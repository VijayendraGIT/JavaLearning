package class2;

public class Conditions {

	public static void main(String[] args) {

		// If
		// If else
		// Ternary condition
		// Switch
		int a =11;
		
		if(a == 11){
			System.out.println("Condition is statified");
		} else {
			System.out.println("Condition not satisfied");
		}
		
		// Ternary condition
		// variable = (Condition Expression) ? TrueValue : FalseValue;

		int y;
		y = (a==10) ? 100:200;
		System.out.println("value of Y ="+y);
		
		
	}

}
