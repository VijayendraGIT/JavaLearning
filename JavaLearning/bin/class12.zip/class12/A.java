package class12;

public interface A {

	// By default public and abstract
	void interfaceMethod1();
	void interfacemethod2();
}
