package class12;

// Abstract class is an idea, whose objects can't get created
// Abstract class may or maynot contain abstract methods - start with abstract keyword
// Abstract class must be inherited and provide implementation of methods

public abstract class AbstractBase {

	public abstract void method1();
	public abstract void method2();

	
}
