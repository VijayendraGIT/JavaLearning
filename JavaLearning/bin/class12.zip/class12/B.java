package class12;

// Abstract is providing implementation to Interface class
abstract public class B implements A{
	
	public void abstractmethod(){
		System.out.println("Inside Abstract method function");
	}

	public abstract void abstractmethod1();
}
