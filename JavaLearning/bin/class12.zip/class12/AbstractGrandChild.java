package class12;

public class AbstractGrandChild extends AbstractChild {
	
	public void method1(){
		System.out.println("In Grandchild class");
	}

}
