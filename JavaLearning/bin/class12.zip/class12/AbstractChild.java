package class12;

public class AbstractChild extends AbstractBase{

	public void method1(){
			System.out.println("Inside Child method 1");
		}


	public void method2(){
		System.out.println("Inside Child method 2");
	}

	/*	
	public static void main(String[] args) {
		
		AbstractChild obj = new AbstractChild();
		obj.method1();
		obj.method2();


	}
*/
}
