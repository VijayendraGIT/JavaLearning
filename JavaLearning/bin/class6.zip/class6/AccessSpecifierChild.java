package class6;

public class AccessSpecifierChild extends AccessSpecifier {
	
	int c;

}
