package class5;
import class6.*;

public class TestAcces extends AccessSpecifier{
	
	

	public static void main(String[] args) {

		TestAcces obj = new TestAcces();
		obj.pro = 10;
		
	}

}
