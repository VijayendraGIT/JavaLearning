package class5;

public class BabyDog extends Dog {
	
	void Cry(){
		System.out.println("Baby Dog cries");
	}

}
