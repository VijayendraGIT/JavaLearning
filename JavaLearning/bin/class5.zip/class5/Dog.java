package class5;

public class Dog extends Animal{
	
	void Bark(){
		System.out.println("Dog Barks");
	}

}
