package class5;

public class Animal {
	void eat(){
		System.out.println("Animal Eats");
	}
}
