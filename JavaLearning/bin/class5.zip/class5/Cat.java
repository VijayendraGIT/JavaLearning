package class5;

public class Cat extends Animal {
	
	void Meow(){
		System.out.println("Cat meows !!");
	}

}
